import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReturnRoutingModule } from './return-routing.module';
import { ReturnComponent } from './return.component';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';

@NgModule({
  declarations: [ReturnComponent],
  imports: [
    CommonModule,
    ReturnRoutingModule,
    MatListModule,
    MatMenuModule,
    MatIconModule,
  ],
})
export class ReturnModule {}
