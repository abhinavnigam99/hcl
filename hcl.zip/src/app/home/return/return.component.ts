import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-return',
  templateUrl: './return.component.html',
  styleUrls: ['./return.component.scss'],
})
export class ReturnComponent implements OnInit {
  private books = [
    {
      title: '1',
      status: 'overdue',
      dateOfBorow: new Date(2021, 3, 13),
      dueDate: new Date(2021, 3, 18),
      memberId: 'abc@xyz.com',
    },
    {
      title: '2',
      status: 'borrowed',
      dateOfBorow: new Date(2021, 3, 16),
      dueDate: new Date(2021, 4, 5),
      memberId: 'abc@xyz.com',
    },
    {
      title: '3',
      status: 'available',
      dateOfBorow: '',
      dueDate: '',
      memberId: 'abc@xyz.com',
    },
    {
      title: '4',
      status: 'borrowed',
      dateOfBorow: new Date(2021, 3, 13),
      dueDate: new Date(2021, 3, 20),
      memberId: 'xyz@abc.com',
    },
    {
      title: '5',
      status: 'borrowed',
      dateOfBorow: new Date(2021, 3, 12),
      dueDate: new Date(2021, 4, 1),
      memberId: 'xyz@abc.com',
    },
    {
      title: '6',
      status: 'overdue',
      dateOfBorow: new Date(2021, 2, 13),
      dueDate: new Date(2021, 2, 14),
      memberId: 'xyz@abc.com',
    },
    {
      title: '7',
      status: 'borrowed',
      dateOfBorow: new Date(2021, 2, 13),
      dueDate: new Date(2021, 2, 20),
      memberId: 'qwerty@qwerty.com',
    },
  ];

  userBooks: any;
  constructor() {}

  ngOnInit(): void {
    let currentUser = localStorage.getItem('email');
    this.userBooks = this.books.filter(
      (el) => el.memberId == currentUser && el.status != 'available'
    );
  }

  returnBook(book) {
    let timeDiff = book.dueDate.getTime() - book.dateOfBorow.getTime();
    let amount;
    let daysDiff = timeDiff / (1000 * 3600 * 24);

    if (daysDiff <= 3 && daysDiff > 0) {
      amount = 20 * daysDiff;
    } else if (daysDiff > 3) {
      amount = 60 + (daysDiff - 3) * 50;
    }

    alert('please pay penalty of Rs.' + amount);
    this.userBooks = this.userBooks.filter((el) => el.title != book.title);
    let index = this.books.findIndex((el) => el.title == book.title);
    this.books[index].status = 'available';
    this.books[index].dueDate = '';
    this.books[index].dateOfBorow = '';
    this.books[index].memberId = '';
  }
}
