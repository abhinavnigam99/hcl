import { Component } from '@angular/core';
import { AuthService } from './auth/auth-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'hcl';

  constructor(private auth: AuthService) {
    let user = localStorage.getItem('loggedIn');
    if (user) {
      let email = localStorage.getItem('email');
      let password = localStorage.getItem('password');
      this.auth.login({ email, password });
    }
  }
}
