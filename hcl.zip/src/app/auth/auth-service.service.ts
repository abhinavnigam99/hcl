import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class AuthService {
  private loggedIn = new BehaviorSubject<boolean>(false);
  private users = [
    {
      email: 'abc@xyz.com',
      password: 'abc',
    },
    {
      email: 'xyz@abc.com',
      password: 'xyz',
    },
    {
      email: 'qwerty@qwerty.com',
      password: 'qwerty',
    },
  ];
  get isLoggedIn() {
    return this.loggedIn.asObservable();
  }

  constructor(private router: Router, private http: HttpClient) {}

  login(user) {
    if (user.email !== '' && user.password !== '') {
      let index = this.users.findIndex(
        (el) => el['email'] === user.email && el['password'] == user.password
      );
      if (index != -1) {
        this.loggedIn.next(true);
        localStorage.setItem('loggedIn', 'true');
        localStorage.setItem('email', user.email);
        localStorage.setItem('password', user.password);
        this.router.navigate(['/home']);
      }
    }
  }

  logout() {
    this.loggedIn.next(false);
    this.router.navigate(['/login']);
  }
}
